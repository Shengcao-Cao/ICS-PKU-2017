/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_213(unsigned *p)
{
    *p = 3281031384U;
}

void setval_219(unsigned *p)
{
    *p = 3284633928U;
}

void setval_366(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_288()
{
    return 3277346863U;
}

unsigned addval_270(unsigned x)
{
    return x + 2425641100U;
}

unsigned getval_198()
{
    return 3284633960U;
}

void setval_291(unsigned *p)
{
    *p = 3284634056U;
}

unsigned addval_125(unsigned x)
{
    return x + 1019449432U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_474()
{
    return 3380134281U;
}

unsigned addval_248(unsigned x)
{
    return x + 2430634312U;
}

void setval_226(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_434()
{
    return 3380920777U;
}

void setval_135(unsigned *p)
{
    *p = 3380136585U;
}

unsigned getval_178()
{
    return 3224945065U;
}

unsigned getval_334()
{
    return 3281046153U;
}

unsigned getval_171()
{
    return 2430634344U;
}

unsigned addval_407(unsigned x)
{
    return x + 3676886665U;
}

unsigned getval_323()
{
    return 3281043849U;
}

void setval_318(unsigned *p)
{
    *p = 2428602824U;
}

void setval_387(unsigned *p)
{
    *p = 3675832713U;
}

unsigned addval_147(unsigned x)
{
    return x + 3534015113U;
}

unsigned addval_332(unsigned x)
{
    return x + 2425539209U;
}

unsigned addval_148(unsigned x)
{
    return x + 3677935241U;
}

unsigned addval_408(unsigned x)
{
    return x + 3767027797U;
}

void setval_130(unsigned *p)
{
    *p = 29611689U;
}

unsigned addval_321(unsigned x)
{
    return x + 3524843145U;
}

unsigned getval_264()
{
    return 3676883593U;
}

void setval_156(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_240()
{
    return 3284846955U;
}

unsigned getval_175()
{
    return 3286272328U;
}

void setval_383(unsigned *p)
{
    *p = 3769190649U;
}

void setval_279(unsigned *p)
{
    *p = 3281046157U;
}

unsigned getval_461()
{
    return 3526934913U;
}

unsigned getval_324()
{
    return 2429979535U;
}

unsigned addval_310(unsigned x)
{
    return x + 3524843145U;
}

unsigned addval_160(unsigned x)
{
    return x + 2425411209U;
}

unsigned addval_155(unsigned x)
{
    return x + 3378566793U;
}

unsigned addval_163(unsigned x)
{
    return x + 3252717896U;
}

void setval_225(unsigned *p)
{
    *p = 3525886345U;
}

void setval_303(unsigned *p)
{
    *p = 3380923017U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
