/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_185(unsigned x)
{
    return x + 3284633672U;
}

unsigned addval_425(unsigned x)
{
    return x + 3347662918U;
}

unsigned getval_206()
{
    return 3267856712U;
}

unsigned getval_292()
{
    return 1485459682U;
}

unsigned getval_492()
{
    return 3281016874U;
}

void setval_418(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_303(unsigned x)
{
    return x + 3243818010U;
}

unsigned addval_494(unsigned x)
{
    return x + 3348125790U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_422()
{
    return 3281311369U;
}

void setval_444(unsigned *p)
{
    *p = 3525362089U;
}

unsigned addval_213(unsigned x)
{
    return x + 3676883593U;
}

void setval_409(unsigned *p)
{
    *p = 3221799305U;
}

unsigned addval_456(unsigned x)
{
    return x + 3525362121U;
}

unsigned getval_244()
{
    return 3373845129U;
}

unsigned addval_163(unsigned x)
{
    return x + 3531917977U;
}

unsigned getval_424()
{
    return 3227566473U;
}

unsigned addval_241(unsigned x)
{
    return x + 2430634056U;
}

void setval_248(unsigned *p)
{
    *p = 2428602676U;
}

void setval_247(unsigned *p)
{
    *p = 3676359305U;
}

void setval_203(unsigned *p)
{
    *p = 3683964553U;
}

unsigned getval_180()
{
    return 197383817U;
}

unsigned getval_488()
{
    return 3527985801U;
}

unsigned getval_161()
{
    return 3353381192U;
}

unsigned getval_250()
{
    return 3682912905U;
}

void setval_255(unsigned *p)
{
    *p = 3229925771U;
}

void setval_271(unsigned *p)
{
    *p = 3523264905U;
}

void setval_114(unsigned *p)
{
    *p = 3281046157U;
}

unsigned getval_238()
{
    return 2464188744U;
}

unsigned getval_331()
{
    return 3281043848U;
}

void setval_313(unsigned *p)
{
    *p = 2425411201U;
}

void setval_423(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_220()
{
    return 3353381192U;
}

void setval_165(unsigned *p)
{
    *p = 3221280393U;
}

unsigned addval_199(unsigned x)
{
    return x + 2429983186U;
}

void setval_130(unsigned *p)
{
    *p = 3767126121U;
}

unsigned addval_473(unsigned x)
{
    return x + 3767097482U;
}

void setval_155(unsigned *p)
{
    *p = 3227568777U;
}

void setval_197(unsigned *p)
{
    *p = 3223901833U;
}

unsigned getval_225()
{
    return 3286272328U;
}

void setval_227(unsigned *p)
{
    *p = 3677935241U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
